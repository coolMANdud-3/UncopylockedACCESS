const urlInput = document.getElementById("gameUrl");
const lookupBtn = document.getElementById("lookupBtn");
const result = document.getElementById("result");
const message = document.getElementById("message");

function showMessage(text, error = false) {
  message.textContent = text;
  message.className = error ? "message error" : "message";
}
function extractPlaceId(value) {
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw new Error("Paste a valid Roblox game URL.");
  }
  const host = url.hostname.toLowerCase();
  if (host !== "roblox.com" && !host.endsWith(".roblox.com")) {
    throw new Error("The link must be from roblox.com.");
  }
  const match = url.pathname.match(/^\/games\/(\d+)(?:\/|$)/i);
  if (!match) throw new Error("This link does not contain a /games/PlaceID/ address.");
  return match[1];
}
function fallbackName(value) {
  try {
    const url = new URL(value.trim());
    const match = url.pathname.match(/^\/games\/\d+\/([^/]+)/i);
    if (!match || !match[1]) return "Roblox experience";
    return decodeURIComponent(match[1]).replace(/[-_]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
  } catch {
    return "Roblox experience";
  }
}
async function getPublicDetails(placeId) {
  const endpoint = `https://games.roblox.com/v1/games/multiget-place-details?placeIds=${encodeURIComponent(placeId)}`;
  const response = await fetch(endpoint);
  if (!response.ok) throw new Error("Roblox metadata is temporarily unavailable.");
  const list = await response.json();
  if (!Array.isArray(list) || !list[0]) throw new Error("Roblox did not return public game details.");
  return list[0];
}
async function getThumbnail(placeId) {
  const endpoint = `https://thumbnails.roblox.com/v1/places/gameicons?placeIds=${encodeURIComponent(placeId)}&size=512x512&format=Png&isCircular=false`;
  const response = await fetch(endpoint);
  if (!response.ok) return null;
  const data = await response.json();
  return data?.data?.[0]?.imageUrl || null;
}
async function copyValue(value) {
  if (!value || value === "Not available") {
    showMessage("That ID is not available.", true);
    return;
  }
  try {
    await navigator.clipboard.writeText(value);
    showMessage("Copied.");
  } catch {
    const temp = document.createElement("textarea");
    temp.value = value;
    temp.style.position = "fixed";
    temp.style.opacity = "0";
    document.body.appendChild(temp);
    temp.select();
    const ok = document.execCommand("copy");
    temp.remove();
    showMessage(ok ? "Copied." : "Copy failed. Select the ID manually.", !ok);
  }
}

lookupBtn.addEventListener("click", async () => {
  showMessage("");
  let placeId;
  try {
    placeId = extractPlaceId(urlInput.value);
  } catch (error) {
    showMessage(error.message, true);
    urlInput.focus();
    return;
  }

  lookupBtn.disabled = true;
  lookupBtn.textContent = "Looking up...";
  result.classList.add("hidden");

  document.getElementById("placeId").textContent = placeId;
  document.getElementById("universeId").textContent = "Not available";
  document.getElementById("gameName").textContent = fallbackName(urlInput.value);
  document.getElementById("gameCreator").textContent = "Place ID extracted from link";
  document.getElementById("lookupState").textContent = "PLACE ID EXTRACTED";
  document.getElementById("thumbnail").hidden = true;
  document.getElementById("thumbFallback").hidden = false;
  result.classList.remove("hidden");

  try {
    const details = await getPublicDetails(placeId);
    document.getElementById("gameName").textContent = details.name || fallbackName(urlInput.value);
    document.getElementById("gameCreator").textContent = details.creatorName ? `By ${details.creatorName}` : "Roblox experience";
    document.getElementById("universeId").textContent = details.universeId ? String(details.universeId) : "Not available";
    document.getElementById("lookupState").textContent = "PUBLIC DETAILS FOUND";

    try {
      const imageUrl = await getThumbnail(placeId);
      if (imageUrl) {
        const img = document.getElementById("thumbnail");
        img.src = imageUrl;
        img.hidden = false;
        document.getElementById("thumbFallback").hidden = true;
        img.onerror = () => {
          img.hidden = true;
          document.getElementById("thumbFallback").hidden = false;
        };
      }
    } catch (_) {
      // The Place ID and name remain usable if thumbnails are unavailable.
    }
    showMessage("Game information retrieved. Copy the Place ID for Studio Lite.");
  } catch (error) {
    // Static GitHub Pages may be blocked by Roblox browser CORS policy.
    // Keep the extracted ID usable instead of pretending metadata loaded.
    showMessage("Place ID extracted. Roblox game details could not be fetched in this browser; the ID is still ready to copy.");
  } finally {
    lookupBtn.disabled = false;
    lookupBtn.innerHTML = 'Find game <span aria-hidden="true">→</span>';
  }
});

document.getElementById("copyPlace").addEventListener("click", () => {
  copyValue(document.getElementById("placeId").textContent);
});
document.getElementById("copyUniverse").addEventListener("click", () => {
  copyValue(document.getElementById("universeId").textContent);
});
document.getElementById("resetBtn").addEventListener("click", () => {
  result.classList.add("hidden");
  urlInput.value = "";
  showMessage("");
  urlInput.focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
});
urlInput.addEventListener("keydown", event => {
  if (event.key === "Enter") lookupBtn.click();
});
