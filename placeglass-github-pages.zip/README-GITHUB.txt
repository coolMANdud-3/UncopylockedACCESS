PLACEGLASS — GITHUB PAGES (PHONE ONLY)

FILES
- index.html
- style.css
- script.js

PUBLISH USING ONLY YOUR PHONE
1. Open github.com in Chrome and sign in.
2. Create a new public repository, for example: placeglass.
3. Tap Add file > Upload files.
4. Upload index.html, style.css and script.js (not the ZIP).
5. Commit the files to the main branch.
6. Open the repository Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch main and folder /(root), then Save.
9. Wait for GitHub Pages to publish. Open the website URL shown there.

USAGE
1. Open the GitHub Pages URL on your phone.
2. Paste a Roblox game URL and tap Find game.
3. Copy the Place ID.
4. Open Studio Lite and use its supported load/open-by-ID option if available to you.

HONEST LIMITS
- This is a static website. It does not need Node.js, a PC, or a backend.
- It always extracts the Place ID from a valid Roblox /games/ URL.
- It attempts to fetch public Roblox metadata directly from the browser. Roblox may block browser requests through CORS, depending on its current policies. If blocked, the Place ID still works and is shown for copying.
- A Place ID is not the game file and does not grant copy/edit permission.
- The site does not download RBXL files or bypass permissions.
